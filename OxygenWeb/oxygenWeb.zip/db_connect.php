<?php
$dbcon = new mysqli("localhost","root","Oxygen000001","login",3306)
or die("<p>ERROR DB1</p>");
?>
