<html>
<head>
<title> oxygenWeb Connect </title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
        <h1>oxygenWeb</h1>
        <h2>Authorised Users Only </h2>
        <div id="loginf">
        <form action="process.php" method="POST">
			<label> Username:
              <input type="text" name="Username" accesskey="u" required>
            </label>
			<label> AccessKey:
              <input type="password" name="password" accesskey="p" required>
            </label>
            <input value="Generate" type="submit">
        </form>
        </div>

</body>

</html>
