<html>
<head>
<title> oxygenWeb Connect </title>
</head>
<body>
        <h1>oxygenWeb</h1>
        <h2>Authorised Users Only </h2>

        <form action="process.php" method="POST">
			
			<label> Username:
              <input type="text" name="Username" accesskey="u" required>
            </label>
			<label> AccessKey:
              <input type="password" name="password" accesskey="p" required>
            </label>
			
            <input value="Generate" type="submit">
        </form>

</body>

</html>
